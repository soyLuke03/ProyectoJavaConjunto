package com.jacaranda.utilities;

public class ProvinciaException extends Throwable {

}
