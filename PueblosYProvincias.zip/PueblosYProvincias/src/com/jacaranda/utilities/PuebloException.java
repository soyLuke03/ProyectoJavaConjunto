package com.jacaranda.utilities;

public class PuebloException {

}
